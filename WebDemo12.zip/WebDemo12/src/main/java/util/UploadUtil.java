package util;


public class UploadUtil {
	
	/**
	 * 随机目录工具类
	 * @param filename
	 * @return
	 */
	public static String getPath(String filename){
		//获取文件哈希值
		int code = filename.hashCode();
		//
		int dir1 = code & 0xf;
		// 
		int dir2 = (code >>> 4) & 0xf;
		return "/"+dir1+"/"+dir2;
	}

}