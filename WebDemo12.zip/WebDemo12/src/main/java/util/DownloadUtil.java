package util;

import java.io.UnsupportedEncodingException;
import net.iharder.Base64;


/**
 * 加密工具类
 */
public class DownloadUtil {
	
	/**
	 * base64
	 * @param fileName
	 * @return
	 */
	public static String base64EncodeFileName(String filename) {

		try {
			return "=?UTF-8?B?"
					+ new String(Base64.encodeBytes(filename
							.getBytes("UTF-8"))) + "?=";
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
}
