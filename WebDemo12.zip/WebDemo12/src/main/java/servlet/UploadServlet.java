package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.UUID;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import util.UploadUtil;


/**
 * 上传文件
 * Servlet implementation class UploadServlet
 */
@WebServlet("/UploadServlet")
public class UploadServlet extends HttpServlet {

	private static final long serialVersionUID = 1294333361466189264L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * 1.创建文件工厂DiskFileItemFactory
		 * 2.创建文件上传解析器	ServletFileUpload
		 * 3.获取表单数据
		 * 4.获取上传文件输入流
		 * 5.写入文件
		 */
		//3.判断提交上来的数据是否是上传表单的数据
		if(!ServletFileUpload.isMultipartContent(request)){
			//按照传统方式获取数据
			throw new RuntimeException("enctype按照传统的方式接受数据");
		}
		
		//使用Apache文件上传组件处理文件上传步骤：
		//1.创建一个DiskFileItemFactory工厂
		DiskFileItemFactory factory = new DiskFileItemFactory();

		//设置工厂的缓冲区的大小，当上传的文件大小超过缓冲区的大小时，就会生成一个临时文件存放到指定的临时目录当中
		factory.setSizeThreshold(1024*1024*3);	
		//设置上传时生成的临时文件的保存目录
		String temp  = getServletContext().getRealPath("/temp");
		factory.setRepository(new File(temp));

		//2.创建一个文件上传解析器
		ServletFileUpload upload = new ServletFileUpload(factory);
		
		//设置上传文件的最大值 
		//upload.setFileSizeMax(1024*1024*5);

		//解决上传文件名的中文乱码
		upload.setHeaderEncoding("UTF-8");
		
		String message = "";  //消息提示
		
		try {
			//4.使用ServletFileUpload解析器解析上传数据，解析结果返回的是一个List<FileItem>集合，每一个FileItem对应一个Form表单的输入项
			List<FileItem> list = upload.parseRequest(request);
			// 遍历list
			for (FileItem fileItem : list) {
				//如果fileitem中封装的是普通输入项的数据
				if(fileItem.isFormField()){
					String name = fileItem.getFieldName();
					//解决普通输入项的数据的中文乱码的问题
					String value = fileItem.getString("UTF-8");
					System.out.println(name+" : "+value);
				}else{
					//如果fileitem中封装的是上传文件，得到上传的文件名称
					String filename = fileItem.getName();
					System.out.println(filename);
					//
					int begin = filename.lastIndexOf("/");
					filename = filename.substring(begin + 1);
					
					//随机目录
					//filename = UUID.randomUUID().toString()+"_"+filename;
					//System.out.println("新的文件目录"+filename);  
					//获取item中的上传文件的输出流
					InputStream in = new BufferedInputStream(fileItem.getInputStream());
					//上传文件保存路径
					String path = getServletContext().getRealPath("/upload");
					
					/**
					// 获取随机目录
					String dir = UploadUtil.getPath(filename);
					File file = new File(path+dir);
					*/
					File file = new File(path);
					
					if(!file.exists())
					{
						// 创建目录
						file.mkdirs();
						System.out.println("上传的目录不存在，创建目录");
					}
/*					
					//判断服务器中有没有相同名字的文件，如果有则改名字重新上传，不覆盖原来的文件
					if((new File(path+"/"+filename).exists())) 
					{
						message = "服务器中已经有相同的文件名，请改名字重新上传";
						request.setAttribute("message", message);
						request.getRequestDispatcher("/jsp/message.jsp").forward(request, response);
						return;
					}
*/				
					//目录文件输入流
					OutputStream os = new BufferedOutputStream(new FileOutputStream(path+"/"+filename));
					
					//判断输入流中的数据是否已经读完的标识
					int len = 0;
					byte [] b = new byte[1024];
					//循环将输入流读入到缓冲区当中
					while((len = in.read(b)) != -1){
						os.write(b, 0, len);
					}
					
					in.close();
					os.close();
					
					//删除处理文件上传时生成的临时文件
					fileItem.delete();
					
					System.out.println("文件上传成功");
					message = "文件上传成功";
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
		request.setAttribute("message", message);
		request.getRequestDispatcher("/jsp/message.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}





