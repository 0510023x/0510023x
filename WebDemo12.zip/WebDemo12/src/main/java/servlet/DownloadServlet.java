package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;


/**
 * 下载指定目录下的文件， /download目录
 * Servlet implementation class DownloadServlet
 */
@WebServlet("/DownloadServlet")
public class DownloadServlet extends HttpServlet {

	private static final long serialVersionUID = 422987322623725234L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * 1.获取要下载的文件名
		 * 2.创建要下载的文件流
		 * 3.获取页面IO流
		 * 4.循环读取和写入数据
		 */
		//获取网页参数
		String filename = request.getParameter("filename");
		//获取下载文件路径
		String path = getServletContext().getRealPath("/download");
		//下载文件流
		InputStream in = new BufferedInputStream(new FileInputStream(path+"/"+filename));
	
		// Content-Type : 	text/html;charset=UTF-8;
		String type = getServletContext().getMimeType(filename);
		// 设置请求类型
		response.setContentType(type);
		// 设置请求头
		response.setHeader("Content-Disposition", "attachment;filename="+URLEncoder.encode(filename, "UTF-8"));

		// 获取页面IO流
		OutputStream os = response.getOutputStream();
		int len = 0;
		byte [] b = new byte[1024];
		while((len = in.read(b)) != -1){
			os.write(b, 0, len);
		}
		in.close();
		os.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
