package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.net.URLEncoder;


import util.DownloadUtil;

/**
 * 下载上传目录的文件文件
 * Servlet implementation class DownloadlistServlet
 */
@WebServlet("/DownloadlistServlet")
public class DownloadlistServlet extends HttpServlet {

	private static final long serialVersionUID = -4013387831215272150L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获取页面返回的下载文件路径
		String path = request.getParameter("path");
		System.out.println(path);
		// 
//		path = new String(path.getBytes("ISO-8859-1"),"UTF-8");
		// d:\\root\\aa\\xxx.mp3
		// 获取文件名的位置
		int index = path.lastIndexOf("/");
		// 获取文件名
		String filename = path.substring(index + 1);
	
		// 
		String type = getServletContext().getMimeType(filename);
		// 设置请求头
		response.setContentType(type);

/*根据浏览器选择加密的方式，这段可以有也可以没有	
		
		// 
		String agent = request.getHeader("User-Agent");
		// Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0  	Base64
		// Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36  �ȸ�
		// Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)	IE  URL
		System.out.println(agent);
		
		// 选择加密方式
		if(agent.contains("Firefox")){
			// 给文件加密
			filename = DownloadUtil.base64EncodeFileName(filename);
		}else{
			// 给文件加密
			filename = URLEncoder.encode(filename, "UTF-8");
			// 
			filename = filename.replace("+", " ");
		}
		
		//选择浏览器
//		if (agent.indexOf("Firefox") > 0) {
//			
//			filename = new String(filename.getBytes("UTF-8"), "ISO-8859-1"); // firefox
//		
//		} else if (agent.toUpperCase().indexOf("MSIE") > 0) {
//			
//			filename = URLEncoder.encode(filename, "UTF-8");// IE
//			filename = filename.replace("+", " ");
//			
//		} else if (agent.indexOf("Chrome") > 0) {
//
//			filename = new String(filename.getBytes("UTF-8"), "ISO-8859-1");// 
//		}
		
*/
		
		
		// 设置请求头
		response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(filename, "UTF-8"));
		// 获取下载文件的输入流
		InputStream in = new BufferedInputStream(new FileInputStream(path));
		// 获取网页的IO流
		OutputStream os = new BufferedOutputStream(response.getOutputStream());
		int len = 0;
		byte [] b = new byte[1024];
		while((len = in.read(b)) != -1){
			os.write(b, 0, len);
		}
		in.close();
		os.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}