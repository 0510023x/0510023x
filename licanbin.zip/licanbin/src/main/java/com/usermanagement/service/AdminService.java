package com.usermanagement.service;

import com.usermanagement.entity.Admin;

/*
 * 
 * 管理员功能 接口类
 */

public interface AdminService {

	Admin findByUsername(String username);
}
