package com.usermanagement.service;

import java.util.List;

import com.usermanagement.entity.User;


/*
 * 用户功能 接口类
 */

public interface UserService {

	/**
	 * 查找全部的用户
	 * 
	 * */
	List<User> findAll();
	
	/**
	 * 通过ID查找全部的用户
	 * */
	User findById(Long id);
	
	/**
	 * 添加用户
	 * */
	boolean add(User user);
	
	/**
	 * 修改用户
	 * */
	boolean update(User user);
	
	/**
	 * 通过Id删除用户
	 * */
	boolean deleteById(Long id);
}
