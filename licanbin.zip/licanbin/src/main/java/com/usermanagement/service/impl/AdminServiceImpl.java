package com.usermanagement.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.usermanagement.entity.Admin;
import com.usermanagement.service.AdminService;
import com.usermanagement.util.JdbcUtils;

/*
 * 管理员功能 实现类
 * 
 */
public class AdminServiceImpl implements AdminService {

	@Override
	public Admin findByUsername(String username) {

		if (username == null) {

			return null;
		}

		Connection connection = JdbcUtils.getConnection();

		if (connection == null) {
			return null;
		}
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Admin admin=null;
		
		String sql="select id,username,password,real_name from admin where username=?";
		
		try {
			//预编译SQL
			pstmt=connection.prepareStatement(sql);
			//ִ执行SQL
			pstmt.setString(1, username);
			//遍历
			rs=pstmt.executeQuery();
			if (rs.next()) {
				admin=new Admin();
				admin.setId(rs.getLong("id"));
				admin.setUsername(rs.getString("username"));;
				admin.setPassword(rs.getString("password"));
				admin.setRealName(rs.getString("real_name"));	
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			
			JdbcUtils.close(rs);
			JdbcUtils.close(pstmt);
			JdbcUtils.close(connection);
		}
		

		return admin;
	}

}
