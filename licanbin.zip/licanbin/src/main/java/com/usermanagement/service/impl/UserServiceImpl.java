package com.usermanagement.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.usermanagement.entity.User;
import com.usermanagement.service.UserService;
import com.usermanagement.util.JdbcUtils;

/*
 * 
 * 用户功能 实现类
 * 
 */

public class UserServiceImpl implements UserService {

	@Override
	public List<User> findAll() {
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		//连接数据库
		connection=JdbcUtils.getConnection();
		List<User> userList=new ArrayList<User>();
		if (connection==null) {
			return userList;
		}
		String sql="select id,username,password,real_name,telephone,id_card_number from `user`";
		
		try {
			//预编译SQL
			pstmt=connection.prepareStatement(sql);
			//ִ执行SQL
			rs=pstmt.executeQuery();
			//遍历
			while(rs.next()) {
				User user=new User();
				user.setId(rs.getLong("id"));
				user.setIdCardNumber(rs.getString("id_card_number"));
				user.setPassword(rs.getString("password"));
				user.setRealName(rs.getString("real_name"));
				user.setTelephone(rs.getString("telephone"));
				user.setUsername(rs.getString("username"));
				
				userList.add(user);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			JdbcUtils.close(rs);
			JdbcUtils.close(pstmt);
			JdbcUtils.close(connection);
		}
		
		return userList;
	}

	@Override
	public User findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(User user) {
		Connection connection=null;
		PreparedStatement pstmt=null;
		
		//连接数据库
		connection=JdbcUtils.getConnection();
		boolean result=false;
		if (connection==null) {
			return result;
		}
		
		String sql="insert into `user`(username,real_name,telephone,id_card_number,password) values (?,?,?,?,?)";
		
		try {
			pstmt=connection.prepareStatement(sql);
			
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getRealName());
			pstmt.setString(3, user.getTelephone());
			pstmt.setString(4, user.getIdCardNumber());
			pstmt.setString(5, user.getPassword());
			
			int count=pstmt.executeUpdate();
			if (count==1) {
				result=true;
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			JdbcUtils.close(pstmt);
			JdbcUtils.close(connection);
		}
		
		
		return result;
	}

	@Override
	public boolean update(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteById(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

}
