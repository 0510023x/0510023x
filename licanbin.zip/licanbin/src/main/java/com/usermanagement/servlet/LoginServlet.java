package com.usermanagement.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.usermanagement.entity.Admin;
import com.usermanagement.service.AdminService;
import com.usermanagement.service.impl.AdminServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.获取用户名   获取页面index.jsp中的<td><input type="text" name="username" style="width: 200px;" /></td>中的username
		String username=request.getParameter("username");
		//2.
		AdminService adminService=new AdminServiceImpl();
		
		//在数据库中通过用户名找到用户并返回用户，如果没有找到用户返回null
		Admin admin=adminService.findByUsername(username);

		if (admin==null) {
			request.setAttribute("message", "用户不存在");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}else {
			//获取密码
			String password=request.getParameter("password");
			if (!admin.getPassword().equals(password)) {
				//密码错误
				request.setAttribute("message", "密码错误");
				request.getRequestDispatcher("/index.jsp").forward(request, response);
				
			}else {
				//登陆成功
				//session可以多次在前后台传递参数   而request.getParameter()只能获取一次参数
				HttpSession session=request.getSession();
				//传递参数 dmin.getUsername()
				session.setAttribute("username", admin.getUsername());
				//
				//  返回用户列表    http://localhost:8080/Demo/UserListServlet
				response.sendRedirect(request.getContextPath()+"/UserListServlet");
			}
			
			
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
