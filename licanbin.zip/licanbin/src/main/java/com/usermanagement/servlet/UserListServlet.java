package com.usermanagement.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.usermanagement.entity.User;
import com.usermanagement.service.UserService;
import com.usermanagement.service.impl.UserServiceImpl;


/**
 * Servlet implementation class UserListServlet
 */
@WebServlet("/UserListServlet")
public class UserListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//防止中文乱码
		request.setCharacterEncoding("utf-8"); 
		//设置请求头
		response.setContentType("text/html;charset=utf-8");

		HttpSession session=request.getSession();
		
		//接受参数  通过username接收
		String username=(String) session.getAttribute("username");
		
		//判断用户名是否存在
		if (username==null) {
			response.sendRedirect(request.getContextPath()+"/index.jsp");
		}else {
			//实例化一个用户功能类
			UserService userService=new UserServiceImpl();
			//连接数据库，查找全部的用户并返回一个用户列表
			List<User> userList=userService.findAll();
			//把用户列表存放在内存空间中，userList可以读到此内存空间中的数据，
			request.setAttribute("userList", userList);
			//返回userlist.jsp    在userlist.jsp中遍历用户列表
			request.getRequestDispatcher("/userlist.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
