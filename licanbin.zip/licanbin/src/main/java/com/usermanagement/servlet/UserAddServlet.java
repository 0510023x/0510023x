package com.usermanagement.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.usermanagement.entity.User;
import com.usermanagement.service.UserService;
import com.usermanagement.service.impl.UserServiceImpl;

/**
 * Servlet implementation class UserAddServlet
 */
@WebServlet("/UserAddServlet")
public class UserAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserAddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 防止中文乱码
		// 
		request.setCharacterEncoding("utf-8");
		// 设置请求头
		response.setContentType("text/html;charset=utf-8");
		//session可以多次在前后台传递参数
		HttpSession session = request.getSession();
		Object obj = session.getAttribute("username");

		// 

		if (obj == null) {
			response.sendRedirect(request.getContextPath() + "/index.jsp");
		} else {
			// 获取浏览器传递的参数
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String realName = request.getParameter("realName");
			String telephone = request.getParameter("telephone");
			String idCardNumber = request.getParameter("idCardNumber");

			//创建一个用户
			User user = new User();

			//把从浏览器获取的参数设置到新建的用户
			user.setIdCardNumber(idCardNumber);
			user.setPassword(password);
			user.setRealName(realName);
			user.setTelephone(telephone);
			user.setUsername(username);

			UserService userService = new UserServiceImpl();

			userService.add(user);
			// 返回用户列表   /Demo
			response.sendRedirect(request.getContextPath() + "/UserListServlet");

		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
