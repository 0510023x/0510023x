package com.usermanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * 连接数据库工具类
 * 
 * */
public final class JdbcUtils {
	private static final String URL = "jdbc:mysql://localhost:3306/licanbin?useSSL=false&characterEncoding=UTF-8";
	private static final String USER = "root";
	private static final String PASSWORD = "13768356052";
	
	private JdbcUtils() {
	}
	static {
		//加载驱动
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 连接数据库
	 * */
	public static Connection getConnection() {
		try {
			return  DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;	
	}
	/**关闭连接，释放资源 Connection,PreparedStatement,ResultSet
	 * */
	public static void close(AutoCloseable closeable) {
		if (closeable!=null) {
			try {
				closeable.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		System.out.println(getConnection());
	}
}
