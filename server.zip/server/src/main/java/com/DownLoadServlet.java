package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 文件下载类， 以字节流下载文件
 * 
 * Servlet implementation class DownLoadServlet
 */
@WebServlet("/DownLoadServlet")
public class DownLoadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownLoadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//得到要下载的文件名
		String fileName = request.getParameter("filename");
		if(fileName != null)
			fileName = new String(fileName.getBytes("UTF-8"),"UTF-8");
		//获取下载路径判断
		String xiazai = request.getParameter("xiazai");
		
		//上传的文件都是保存在/WEB-INF/upload目录下的子目录当中
		String fileSaveRootPath = this.getServletContext().getRealPath("/WEB-INF/upload");
					
		//得到要下载的文件
		File file = new File(fileSaveRootPath+File.separator+fileName);
		
		if(xiazai.equalsIgnoreCase("2"))
		{
			fileSaveRootPath = ListFileServlet_open.xiazai_mulu;
			file = new File(fileSaveRootPath+File.separator+fileName);
		}	
		
		//如果文件不存在
		if(!file.exists()) {
			request.setAttribute("message", "您要下载的资源已经被删除");
			request.getRequestDispatcher("/message.jsp").forward(request, response);
			return;
		}

		//设置响应头，控制浏览器下载该文件
		//Content-Disposition响应头，表示收到的数据怎么处理   attachment表示附件，表示下载使用    fileName表示指定下载的文件名
		response.setHeader("content-disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));

		//读取要下载的文件，保存到文件输入流
		InputStream is = new FileInputStream(file);
		//FileInputStream fis = new FileInputStream(fileSaveRootPath + File.separator + fileName);

		//创建输出流
		OutputStream fos = response.getOutputStream();
		//ServletOutputStream fos = response.getOutputStream();

		//设置缓冲区
		byte[] buffer = new byte[1024*4];
		int len = 0;
		while((len=is.read(buffer))!=-1) {
			fos.write(buffer,0,len);
		}
		//关闭输入流
		is.close();
		//关闭输出流
		fos.close();
		

	}


}
