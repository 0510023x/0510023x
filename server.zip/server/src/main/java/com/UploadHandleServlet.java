package com;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;


/**
 * 文件上传类，以字节流上传文件
 * 
 * 在浏览器通过http://localhost:8080/Server/upload.jsp上传文件
 */
@WebServlet("/UploadHandleServlet")
public class UploadHandleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadHandleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//得到上传文件的保存目录，将上传的文件存放于WEB-INF目录下，不允许外界访问，保证了上传问价的安全
		String savePath = this.getServletContext().getRealPath("/WEB-INF/upload");
		//不安全的文件保存路径
		//String savePath = "/Users/holmes/eclipse-workspace/Server/data";
		
		//生成临时文件保存目录
		String tempPath = this.getServletContext().getRealPath("/WEB-INF/temp");
		File tempSaveFile = new File(tempPath);
		if(!tempSaveFile.exists()&&!tempSaveFile.isDirectory()) {
			System.out.println("目录或文件不存在,创建文件");
			tempSaveFile.mkdir();
		}
		
		String message = "";  //消息提示

		InputStream is = null;
		FileOutputStream fos = null;
		try {
			//使用Apache文件上传组件处理文件上传步骤：
			//1.创建一个DiskFileItemFactory工厂
			DiskFileItemFactory diskFileItemFactory = new DiskFileItemFactory();
			//设置工厂的缓冲区的大小，当上传的文件大小超过缓冲区的大小时，就会生成一个临时文件存放到指定的临时目录当中
			diskFileItemFactory.setSizeThreshold(1024*100);
			//设置上传时生成的临时文件的保存目录
			diskFileItemFactory.setRepository(tempSaveFile);
			//2.创建一个文件上传解析器
			ServletFileUpload fileUpload = new ServletFileUpload(diskFileItemFactory);
			//解决上传文件名的中文乱码
			fileUpload.setHeaderEncoding("UTF-8");
			/**
			//监听文件上传进度
			fileUpload.setProgressListener(new ProgressListener() {
				public void update(long pBytesRead, long pContentLength, int arg2) {
					System.out.println("文件大小为:"+pContentLength+",当前已处理:"+pBytesRead);
				}
			});
			*/
			//3.判断提交上来的数据是否是上传表单的数据
			if(!ServletFileUpload.isMultipartContent(request)) {
				//按照传统方式获取数据
				
				return;
			}
			//4.使用ServletFileUpload解析器解析上传数据，解析结果返回的是一个List<FileItem>集合，每一个FileItem对应一个Form表单的输入项
			List<FileItem> list = fileUpload.parseRequest(request);

			for(FileItem item : list) {
				//如果fileitem中封装的是普通输入项的数据
				if(item.isFormField()) {
					String name = item.getFieldName();
					//解决普通输入项的数据的中文乱码的问题
					String value = item.getString("UTF-8");
					String value1 = new String(name.getBytes("iso8859-1"),"UTF-8");
					System.out.println(name+" "+value);
					System.out.println(name+" "+value1);
				}else {
					//如果fileitem中封装的是上传文件，得到上传的文件名称
					String fileName = item.getName();
					System.out.println(fileName);
					if(fileName==null||fileName.trim().equals("")) {
						continue;
					}
					//注意：不同的浏览器提交的文件名是不一样的，有些浏览器提交上来的文件名是带有路径的，而有些只是单纯的文件名
					//处理获取到的上传文件名的路径部分，只保留文件名部分
					fileName = fileName.substring(fileName.lastIndexOf(File.separator)+1);
					//得到上传文件的扩展名
					String fileExtName = fileName.substring(fileName.lastIndexOf(".")+1);
	
					//如果需要限制上传的文件类型，那么可以通过文件的扩展名来判断上传的文件类型是否合法
					System.out.println("上传文件的扩展名为:"+fileExtName);
					//获取item中的上传文件的输入流
					is = item.getInputStream();
					System.out.println("文件保存路径为:"+savePath);
					//创建一个文件输出流
					fos = new FileOutputStream(savePath+File.separator+fileName);  //File.separator获取/
					//  /Users/holmes/eclipse-workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/Server/WEB-INF/upload/ssh.sh
					//创建一个缓冲区
					byte buffer[] = new byte[1024*4];
					//判断输入流中的数据是否已经读完的标识
					int length = 0;
					//循环将输入流读入到缓冲区当中
					while((length = is.read(buffer))>0) {
						//使用FileOutputStream输出流将缓冲区的数据写入到指定的目录(savePath + "//"+fileName)当中
						fos.write(buffer, 0, length);
					}
					//删除处理文件上传时生成的临时文件
					item.delete();
					message = "文件上传成功";
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
			message = "文件上传失败";
		} finally {
			//释放资源
			if(is != null) {
				is.close();
			}
			if(fos != null) {
				fos.close();
			}
			
		}
		request.setAttribute("message", message);
		request.getRequestDispatcher("/message.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}
