package com;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class ListFileServlet_open
 */
@WebServlet("/ListFileServlet_open")
public class ListFileServlet_open extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// 获取上传文件目录
	String uploadFilePath = "/Users/holmes/Desktop";
	String filename ="";
	
	//保存上一级目录
	String upFilePath;
	
	//静态目录
	public static String xiazai_mulu;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ListFileServlet_open() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//在页面“打开”链接被点击时，返回的参数
		filename=request.getParameter("name");
		System.out.println(filename);
		//在页面“返回上一级目录”被点击时，返回的参数
		String upFile = request.getParameter("upFile");

		//当在页面点击“打开”，执行打开的文件夹的路径
		if(filename !=null)
		{
			if(uploadFilePath.equalsIgnoreCase("/"))
			{
				uploadFilePath = uploadFilePath + filename;
			}
			else
			{
				uploadFilePath = uploadFilePath + "/"+filename;
			}
		}

		//当在页面点击“返回上一级目录”，执行返回上一级目录路径
		if(upFile != null) {
			if(upFile.equalsIgnoreCase("1"))
			{	
				System.out.println("返回上一级目录");
				if(uploadFilePath.equalsIgnoreCase("/Users"))
				{
					uploadFilePath = "/";
				}
				else if(uploadFilePath.equalsIgnoreCase("/"))
				{
					uploadFilePath = "/";
				}
				else
				{
					uploadFilePath = uploadFilePath.substring(0, uploadFilePath.lastIndexOf("/"));
				}
			}
		}
		//保存静态目录
		xiazai_mulu = uploadFilePath;
		System.out.println(uploadFilePath);
		File file = new File(uploadFilePath);
		// 存储要下载的文件名
		Map<String, String> fileMap = new HashMap<String, String>();
		
		// 递归遍历filepath目录下的所有文件和目录，将文件的文件名存储到map集合中
	    fileList(file, fileMap, request, response);

		// 将Map集合发送到listfile.jsp页面进行显示
		// request.setAttribute("fileMap", fileMap);
		// request.getRequestDispatcher("/listfile.jsp").forward(request, response);
		// session可以多次在前后台传递参数 而request.getParameter()只能获取一次参数
		HttpSession session = request.getSession();
		// 传递参数 dmin.getUsername()
		session.setAttribute("fileMap", fileMap);
		//
		// 返回用户列表 http://localhost:8080/Demo/UserListServlet
		response.sendRedirect(request.getContextPath() + "/listfile_open.jsp");
	}
	
	
	//递归遍历指定目录下的所有文件
		public void fileList(File file, Map<String, String> fileMap,HttpServletRequest request, HttpServletResponse response) {
			//如果file代表的不是一个文件，而是一个目录
			if(!file.isFile()) {
				try {
					//列出该目录下的所有文件和目录
					File[] files = file.listFiles();
					//遍历files[]数组
					for(File file2 : files) {
						String realName = file2.getName().substring(file2.getName().lastIndexOf("_")+1);
						//隐藏的文件不显示(即 .文件)
						if(realName.substring(0,1).equalsIgnoreCase("."))
						{
							System.out.println("隐藏文件不显示");
						}
						else
						{
							fileMap.put(file2.getName(), realName);
						}
					}
				}catch(NullPointerException e){
					System.out.println("这不是一个目录");
					request.setAttribute("message", "这是一个目录不能下载，请刷新页面，重新下载");
					try {
						request.getRequestDispatcher("/message.jsp").forward(request, response);
					} catch (ServletException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					return;
				}
			}else {
				/**
				 * 处理文件名，上传后的文件是以uuid_文件名的形式去重新命名的，去除文件名的uuid_部分
				 * file.getName().indexOf("_")检索字符串中第一次出现"_"字符的位置，如果文件名类似于:95544-45664-465_李_灿_彬.avi
				 * 那么file.getName().substring(file.getName().indexOf("_")+1)处理之后就可以得到李_灿_彬.avi部分
				 * 
				 */
				String realName = file.getName().substring(file.getName().lastIndexOf("_")+1);
				//隐藏文件不显示
				if(realName.substring(0,1).equalsIgnoreCase("."))
				{
					System.out.println("隐藏文件不显示");
				}
				else
				{
					//file.getName()得到得失文件的原始名称，这个名称是唯一的，因此可以作为key，realName是处理过后的名称，有可能会重复
					fileMap.put(file.getName(), realName);
				}
			}
		}


}
